Thank you for using Themeweaver!

## Instructions

### VSCode

1. Copy the contents into *~/.vscode/extensions/*.
1. Restart VSCode or reload the window with the `Developer: Reload Window` action.
1. Open the theme switcher with `⌘/ctrl K + T`. There should be a light and dark themes with the name you entered above.

### Xcode

1. Unzip the contents anywhere
1. Copy **xcode/Void-light.xccolortheme** and **xcode/Void-dark.xccolortheme** into **~/Library/Developer/Xcode/UserData/FontAndColorThemes**.

### Slack

Slack theme customizations are pretty limited, but here is a Slack theme based on the theme you built! Copy and paste the code into the custom theme section of the Slack preferences.

```
#000000,#777777,#F3F3F3,#777777,#000000,#F3F3F3,#7AFFA7,#343434,#010101,#F3F3F3
```

```
#B2B2B2,#000000,#000000,#000000,#B2B2B2,#000000,#00CC44,#777777,#777777,#000000
```

### Jetbrains (IntelliJ, Android Studio, WebStorm, PhpStorm, etc.)

1. Unzip the contents anywhere
1. In the Jetbrains application (Android studio, Webstorm, etc.) open the preferences
1. Go to **Editor > Color Scheme > General**
1. Click on the button with 3 dots in the top and click on **Import Scheme**
1. Select one of the .icls files **jetbrains/Void-light.icls** and **jetbrains/Void-dark.icls**

### iTerm

1. Launch iTerm 2
1. Press `CMD+i`
1. Go to the **Colors** tab
1. Click on **Color Presets**
1. Click on **Import**
1. Select the **Void-light.itermcolors** and **Void-dark.itermcolors** files in the **iterm** folder

